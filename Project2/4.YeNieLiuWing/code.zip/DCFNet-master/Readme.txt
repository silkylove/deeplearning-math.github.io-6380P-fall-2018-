Code used:
[train,test,time]=optimal(14)
