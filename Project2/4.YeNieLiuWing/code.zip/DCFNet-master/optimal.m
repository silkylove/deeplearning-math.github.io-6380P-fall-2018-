function [train,test,time]=optimal(number_of_k)
train=zeros(1,number_of_k);
test=zeros(1,number_of_k);
time=zeros(1,number_of_k);
for i=1:number_of_k
    tic;
    [train(1,i),test(1,i)]=mnist_test(i);
    time(1,i)=toc;
end

    