Example scripts to train a spatial transformer network [1]
for cluttered MNIST dataset.

Demonstrates how to initialize and train the network.

References:
-----------
1. Jaderberg, Max, Karen Simonyan, and Andrew Zisserman
   Spatial transformer networks
   Advances in Neural Information Processing Systems, 2015
